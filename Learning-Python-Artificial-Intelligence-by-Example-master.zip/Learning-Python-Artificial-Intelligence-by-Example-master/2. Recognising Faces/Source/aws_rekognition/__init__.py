from aws_rekognition.aws_rekognition import train, test

