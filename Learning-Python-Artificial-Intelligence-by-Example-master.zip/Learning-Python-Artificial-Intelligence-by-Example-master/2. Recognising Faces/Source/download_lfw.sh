#!/usr/bin/env bash

wget http://vis-www.cs.umass.edu/lfw/lfw.tgz
tar -zxvf lfw.tgz -P ./lfw
rm lfw.tgz